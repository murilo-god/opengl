#include <GL/glew.h> // include GLEW and new version of GL on Windows
#include <GLFW/glfw3.h> // GLFW helper library
#include <stdio.h>
#include "base_gl/base_window.h"
#include "base_gl/base_input.h"
#include <Windows.h>
#include "..//resource.h"



int main() 
{
	GLWindow window(800, 600, "Andrioli Test");
	window.Init();
	std::vector<GLint> key_list = { GLFW_KEY_ESCAPE, GLFW_KEY_F11 };
	KeyInput inputHandler(key_list);
	inputHandler.setupKeyInputs(window.GetWindowID());
	inputHandler.setIsEnabled(1);
	
	//window.SetFullScreen(true);

	double previousTime = glfwGetTime();
	int frameCount = 0;

	while (!glfwWindowShouldClose(window.GetWindowID())) 
	{
		if (inputHandler.getIsKeyDown(GLFW_KEY_F11))
		{
			std::cout << "a!";
		}
		// Measure speed
		double currentTime = glfwGetTime();
		frameCount++;
		// If a second has passed.
		if (currentTime - previousTime >= 1.0)
		{
			// Display the frame count here any way you want.
			std::cout << (frameCount) << std::endl;

			frameCount = 0;
			previousTime = currentTime;
		}
		window.ClearWindow(1.0f, 1.0f, 1.0f);


		window.UpdateWindow();
	}


	// close GL context and any other GLFW resources
	glfwTerminate();
	return 0;
}