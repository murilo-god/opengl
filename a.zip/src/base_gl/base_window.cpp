#include "base_window.h"

void GLWindow::wResize(int cx, int cy)
{
	wUpdateViewPort = true;
}

GLWindow::GLWindow(GLint width, GLint height, std::string name)
	: wWidth(width), wHeight(height), wWinName(name), wPosX(0), wPosY(0), wViewPortX(0), wViewPortY(0), wFullscreen(0)
{
}

void GLWindow::Init()
{
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW. How did you do that, mate??\n");
		exit(-1);
	}

	//glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_REFRESH_RATE, 60);

	//giving window pointer a value to window!
	wWinID = glfwCreateWindow(wWidth, wHeight, wWinName.c_str(), NULL, NULL);

	//detect if the window was created
	if (wWinID == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible.\n");
		glfwTerminate();
		exit(-1);
	}



	//make context
	glfwMakeContextCurrent(wWinID);

	glfwSetWindowUserPointer(wWinID, this);
	glfwSetWindowSizeCallback(wWinID, GLWindow::CallbackResize);

	wMonitor = glfwGetPrimaryMonitor();
	glfwGetWindowSize(wWinID, &wWidth, &wHeight);
	glfwGetWindowPos(wWinID, &wPosX, &wPosY);
	wUpdateViewPort = true;



	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		glfwTerminate();
		exit(-1);
	}

	/*
	const GLFWvidmode* mode = glfwGetVideoMode(glfwGetPrimaryMonitor());

	glfwSetWindowMonitor(windowID, glfwGetPrimaryMonitor(), 0, 0, mode->width, mode->height, mode->refreshRate);
	*/

	glEnable(GL_DEPTH_TEST); // enable depth-testing
	glDepthFunc(GL_LESS); // depth-testing interprets a smaller value as "closer"

	//std::cout << mode->refreshRate << "\n\n\n\n\n\n";




	glfwSwapInterval(1);
}

GLWindow::~GLWindow()
{
	glfwTerminate();
}

void GLWindow::SetHint(int hint, int value)
{
	glfwWindowHint(hint, value);
}

void GLWindow::SetInput(int mode, int value)
{
	glfwSetInputMode(wWinID, mode, value);
}

void GLWindow::SetVSync(int value)
{
	glfwSwapInterval(value);
}

void GLWindow::SwapBuffers()
{
	glfwSwapBuffers(wWinID);
}

int GLWindow::WindowShouldClose()
{
	return glfwWindowShouldClose(wWinID);
}

int GLWindow::GetKey(int key)
{
	return glfwGetKey(wWinID, key);
}

GLFWwindow* GLWindow::GetWindowID()
{
	return wWinID;
}

void GLWindow::CallbackResize(GLFWwindow* window, int cx, int cy)
{
	void* ptr = glfwGetWindowUserPointer(window);
	if (GLWindow * wndPtr = static_cast<GLWindow*>(ptr))
		wndPtr->wResize(cx, cy);
}

bool GLWindow::IsFullscreen(void)
{
	return glfwGetWindowMonitor(wWinID) != nullptr;
}

void GLWindow::SetFullScreen(bool fullscreen)
{

	if (IsFullscreen() == fullscreen)
		return;

	if (fullscreen)
	{
		// backup window position and window size
		glfwGetWindowPos(wWinID, &wPosX, &wPosY);
		glfwGetWindowSize(wWinID, &wWidth, &wHeight);

		// get resolution of monitor
		const GLFWvidmode* mode = glfwGetVideoMode(glfwGetPrimaryMonitor());

		// switch to full screen
		glfwSetWindowMonitor(wWinID, wMonitor, 0, 0, mode->width, mode->height, mode->refreshRate);
		glfwSwapInterval(1);
	}
	else
	{
		const GLFWvidmode* mode = glfwGetVideoMode(glfwGetPrimaryMonitor());
		// restore last window size and position
		glfwSetWindowMonitor(wWinID, nullptr, wPosX, wPosY, wWidth, wHeight, mode->refreshRate);
		glfwSwapInterval(1);
	}

	wUpdateViewPort = true;

}

void GLWindow::CloseWindow()
{
	glfwSetWindowShouldClose(wWinID, true);
}

void GLWindow::UpdateViewPort()
{
	if (wUpdateViewPort)
	{
		glfwGetFramebufferSize(wWinID, &wViewPortX, &wViewPortY);
		glViewport(0, 0, wViewPortX, wViewPortY);
		wUpdateViewPort = false;
	}
}

void GLWindow::UpdateWindow()
{
	glfwPollEvents();
	glfwSwapBuffers(wWinID);
}

void GLWindow::ClearWindow(float r, float g, float b)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(r, g, b, 1.0f);
}


