#pragma once
#include "base_window.h"
#include "base_input.h"

class GLProgram
{
private:

public:

};