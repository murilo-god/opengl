#pragma once
#include <iostream>
#include <string>
#include <GL/glew.h>
#include <GLFW/glfw3.h>


class GLWindow
{
private:
	GLFWwindow* wWinID;
	GLint wWidth;
	GLint wHeight;

	GLboolean wFullscreen;
	std::string wWinName;

	GLint wPosX;
	GLint wPosY;

	GLint wViewPortX;
	GLint wViewPortY;

	GLFWmonitor* wMonitor;

	GLboolean wUpdateViewPort;

	void wResize(int cx, int cy);
public:
	GLWindow(GLint width, GLint height, std::string name);
	~GLWindow();

	void Init();

	void SetHint(int hint, int value);
	void SetInput(int mode, int value);
	void SetVSync(int value);
	void SwapBuffers();
	int WindowShouldClose();
	int GetKey(int key);
	GLFWwindow* GetWindowID();

	static void CallbackResize(GLFWwindow* window, int cx, int cy);
	bool IsFullscreen(void);
	void SetFullScreen(bool fullscreen);
	void CloseWindow();

	void UpdateViewPort();

	void UpdateWindow();
	void ClearWindow(float r, float g, float b);

};