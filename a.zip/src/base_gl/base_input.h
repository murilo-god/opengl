#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <map>
#include <vector>

struct KeyState
{
	GLint code;
	GLboolean pressed;
	GLint pressedState; // -1 -> Repeat // 0 -> Single - No // 1 -> Single - Yes
	GLboolean enabled;
};

class KeyInput 
{
private:
	
	void setIsKeyDown(int key, bool isDown);
	
	std::map<int, bool> _keys;
	
	bool _isEnabled;

	std::map<GLint, GLboolean> _lastFrameKey;
	
	static void callback(GLFWwindow* window, int key, int scancode, int action, int mods);
	
	static std::vector<KeyInput*> _instances;
	
public:
	
	KeyInput(std::vector<int> keysToMonitor);
	~KeyInput();
	
	bool getIsKeyDown(int key);
	
	bool getIsEnabled() { return _isEnabled; }
	void setIsEnabled(bool value) { _isEnabled = value; }
	static void setupKeyInputs(GLFWwindow* window);
	
};